1/40 of this
