I have "1/4" of this.
