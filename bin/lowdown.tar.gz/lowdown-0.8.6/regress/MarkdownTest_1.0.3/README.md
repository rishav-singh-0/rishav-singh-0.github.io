This contains Markdown testing suites, currently limited to the Markdown
suite v1.0.3.

It's in its original form except for the following:

- *Amps and angle encoding.html* has line 9 changed so that \> must be
  escaped to \&gt;.

- *Backslash escapes.html* has the same change on line 23.
