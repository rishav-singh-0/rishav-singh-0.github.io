"'hello'" he said
