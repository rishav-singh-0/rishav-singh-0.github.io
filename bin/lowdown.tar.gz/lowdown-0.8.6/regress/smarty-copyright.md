foo (c) bar
